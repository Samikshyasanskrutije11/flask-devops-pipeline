# Flask DevOps Pipeline — Python → Docker → Jenkins → Terraform → AWS EC2

A small but complete DevOps project: a Python/Flask web service that is tested, containerised,
pushed to Docker Hub by Jenkins, and deployed onto an AWS EC2 instance provisioned with Terraform.

```
Developer push
      │
      ▼
   GitHub  ──webhook──▶  Jenkins
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
   pytest + flake8    docker build/push    terraform apply
                            │                   │
                            └────────▶ SSH deploy ◀──── AWS EC2 (Docker)
                                             │
                                             ▼
                                   http://<ec2-public-ip>
```

## Tech stack

| Layer | Tool |
|---|---|
| Application | Python 3.11, Flask, Gunicorn |
| Testing / lint | pytest, flake8 |
| Containerisation | Docker, Docker Compose |
| CI/CD | Jenkins (declarative pipeline) |
| Infrastructure as Code | Terraform (AWS provider) |
| Cloud | AWS EC2, Security Groups |

## Repository layout

```
flask-devops-pipeline/
├── app/
│   ├── app.py                  # Flask app factory + routes
│   ├── wsgi.py                 # Gunicorn entrypoint
│   ├── requirements.txt        # runtime deps
│   ├── requirements-dev.txt    # test/lint deps
│   └── templates/index.html    # landing page
├── tests/test_app.py           # pytest suite
├── Dockerfile                  # non-root, healthcheck, gunicorn
├── .dockerignore
├── docker-compose.yml          # local run
├── Jenkinsfile                 # full CI/CD pipeline
├── terraform/
│   ├── versions.tf             # provider + optional S3 backend
│   ├── variables.tf
│   ├── main.tf                 # AMI lookup, security group, EC2
│   ├── user_data.sh            # installs Docker on boot
│   ├── outputs.tf              # public IP, app URL, ssh command
│   └── terraform.tfvars.example
├── scripts/
│   ├── run_local.sh
│   └── deploy_manual.sh
├── .flake8
├── .gitignore
└── README.md
```

## Endpoints

| Route | Purpose |
|---|---|
| `GET /` | HTML page showing version, environment, container hostname |
| `GET /health` | JSON liveness probe — used by Docker HEALTHCHECK and Jenkins |
| `GET /api/info` | JSON build/runtime metadata |

---

## 1. Run locally

```bash
git clone https://github.com/<your-username>/flask-devops-pipeline.git
cd flask-devops-pipeline
bash scripts/run_local.sh          # venv + tests + dev server on :5000
```

## 2. Run with Docker

```bash
docker build -t flask-devops-pipeline:local --build-arg APP_VERSION=local .
docker run -d -p 5000:5000 --name flask-app flask-devops-pipeline:local
curl http://localhost:5000/health
# or
docker compose up --build
```

## 3. Provision infrastructure with Terraform

Prerequisites: AWS account, AWS CLI configured (`aws configure`), Terraform ≥ 1.5,
and an existing EC2 key pair in your chosen region.

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars: set key_name, and ssh_allowed_cidr to YOUR_IP/32

terraform init
terraform validate
terraform plan
terraform apply          # ~1 minute
terraform output app_url
```

This creates:
- a security group (port 80 open to the world, port 22 open to your CIDR),
- a `t2.micro` Ubuntu 22.04 instance with Docker installed via `user_data.sh`.

Tear everything down when you are done so you are not billed:

```bash
terraform destroy
```

## 4. Deploy the container to EC2

Manually (this is exactly what the Jenkins stage automates):

```bash
./scripts/deploy_manual.sh <ec2-public-ip> ~/keys/my-ec2-keypair.pem \
    <dockerhub-user>/flask-devops-pipeline:latest
```

Then open `http://<ec2-public-ip>`.

## 5. Set up the Jenkins pipeline

**Install on the Jenkins host:** Docker, Terraform, Python 3, `git`, `curl`.
Add the Jenkins user to the docker group: `sudo usermod -aG docker jenkins && sudo systemctl restart jenkins`.

**Plugins:** Git, Pipeline, Docker Pipeline, Credentials Binding, SSH Agent, JUnit.

**Credentials** (Manage Jenkins → Credentials) — the IDs must match the `Jenkinsfile`:

| ID | Kind | Value |
|---|---|---|
| `dockerhub-creds` | Username with password | Docker Hub username + access token |
| `aws-access-key-id` | Secret text | AWS access key ID |
| `aws-secret-access-key` | Secret text | AWS secret access key |
| `ec2-ssh-key` | SSH username with private key | username `ubuntu`, contents of your `.pem` |

**Create the job:** New Item → Pipeline → Pipeline script from SCM → Git → your repo URL →
Script Path `Jenkinsfile`. Enable *GitHub hook trigger for GITScm polling* and add a GitHub
webhook pointing to `http://<jenkins-host>:8080/github-webhook/`.

**Edit one line** in the `Jenkinsfile` before the first run:

```groovy
DOCKERHUB_USER = 'your-dockerhub-username'
```

Also create `terraform/terraform.tfvars` on the Jenkins host (it is git-ignored) or pass
`-var="key_name=..."` in the Terraform stage.

### Pipeline stages

1. **Checkout** — pull the commit from GitHub.
2. **Install & Test** — venv, `flake8`, `pytest` with JUnit report published to Jenkins.
3. **Build Docker Image** — tagged `:$BUILD_NUMBER` and `:latest`.
4. **Smoke Test Image** — runs the container, polls `/health`, then removes it.
5. **Push to Docker Hub** — login via credentials, push both tags.
6. **Terraform Provision** — `init`/`validate`/`plan`/`apply`, writes the public IP to a file.
7. **Deploy to EC2** — SSH in, `docker pull`, replace the running container on port 80.
8. **Verify Deployment** — polls `http://<ec2-ip>/health` and fails the build if unhealthy.

---

## Notes and good practices demonstrated

- Multi-tag immutable images (`:BUILD_NUMBER`) so any build can be rolled back.
- Container runs as a **non-root** user with a Docker `HEALTHCHECK`.
- No secrets in the repo: credentials come from Jenkins, `*.pem`/`terraform.tfvars`/`*.tfstate` are git-ignored.
- Terraform looks the AMI up dynamically instead of hard-coding an ID.
- `terraform apply` is idempotent, so re-running the pipeline updates the app without recreating the server.

## Possible extensions

- Push images to Amazon ECR instead of Docker Hub.
- Replace the SSH deploy with ECS/EKS or an Auto Scaling Group + Load Balancer.
- Add Nginx as a reverse proxy with HTTPS via Let's Encrypt.
- Add Prometheus + Grafana monitoring, or Ansible for configuration management.
- Move Terraform state to the S3 backend already stubbed in `versions.tf`.

## License

MIT
